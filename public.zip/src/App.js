import { useEffect, useState } from 'react';
import SideBar from './components/SideBar';
import Data from './components/Data';
import './App.css';
import axios from 'axios'


// import DataFetch from './components/DataFetch';


function App() {
  const [informations, setInformations] = useState([])
 
const url = 'http://localhost:44364/api/onboarding/user/conan.edogawa/'
 
const getInfoHandler = () => {
 axios.get(url).then(res => {
const personInfo = res.data
setInformations(personInfo)
// console.log(personInfo)
 })
 }
useEffect(() => {
getInfoHandler()
 }, [])
  return (
    <div className="App">
   
        <div className="people-main-container">
          <SideBar display-name="personalInfo[0].display_name"/>
          <Data informations = {informations}/>
    
         
        </div>
    </div>
  );

}

export default App;
