import React, { useState } from "react";
import "../styles/ContactInfo.css";
import {FaPencilAlt} from 'react-icons/fa'



function ContactInfo({informations}) {

    const [isEdit, setIsEdit] = useState(false)
    // const [isCancel, setCancel] = useState(false)

    const edit = () => {
        setIsEdit(true)
    }

    const cancel = () => {
        setIsEdit(false)
    }
    
    return (
            
        <div>
            {
                informations.map(info => <div className="contact-info">
                <div className="contact-info-body">
                <div onClick={edit} className="edit-btn" value="Edit" >
                    Edit <FaPencilAlt/>
                    </div>
                    <div className="contactInfo">Contact Info</div>
                    <div className="title">Mobile Phone</div>
                    <div className="dataInfo">{info.mobilePhone}</div>
                    <div className="title">Email Address</div>
                    <div className="dataInfo">{info.emailAddress}</div>
                    <div className="title">Emergency Contact</div><br/>
                    
                   
                    <div className="title">Name</div>
                    <div className="dataInfo">{info.emergencyName}</div>
                    <div className="title">Address</div>
                    <div className="dataInfo">{info.emergencyAddress}</div>
                    <div className="title">District</div>
                    <div className="dataInfo">{info.emergencyDistrict}</div>
                    <div className="title">City</div>
                    <div className="dataInfo">{info.emergencyCity}</div>
                    <div className="title">Country</div>
                    <div className="dataInfo">{info.emergencyCountry}</div>
                    <div className="title">Phone</div>
                    <div className="dataInfo">{info.emergencyPhone}</div>




                    </div><div className="edit-contact-info" style={{display: isEdit ? 'block' : 'none' }}>
                        <div className="editTitle">Mobile Phone</div>
                        <input type="text" placeholder={info.mobilePhone}/  >
                        <div className="editTitle">Email Address</div>
                        <input type="text" placeholder={info.emailAddress}/  >
                        <div className="editTitle">Emergency Name</div>
                        <input type="text" placeholder={info.emergencyName}/  >
                        <div className="editTitle">Emergency Address</div>
                        <input type="text" placeholder={info.emergencyAddress}/  >
                        <div className="editTitle">Emergency District</div>
                        <input type="text" placeholder={info.emergencyDistrict}/  >
                        <div className="editTitle">Emergency City</div>
                        <input type="text" placeholder={info.emergencyCity}/  >
                        <div className="editTitle">Emergency Country</div>
                        <input type="text" placeholder={info.emergencyCountry}/  >
                        <div className="editTitle">Emergency Phone</div>
                        <input type="text" placeholder={info.emergencyPhone}/  >

                        
                    <div>   
                        <div className="save-btn">
                            <div class="save-btn-text">Save</div>
                        </div>
                        <div className="cancel-btn" >
                            <div onClick={cancel} class="cancel-btn-text">Cancel</div>
                        </div>
                    </div>
                    </div>      
            </div>)
            }
        </div>

    )
       
    
}

export default ContactInfo