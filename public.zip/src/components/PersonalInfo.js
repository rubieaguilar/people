import React, { useState } from "react";
import "../styles/PersonalInfo.css";
import {FaPencilAlt} from 'react-icons/fa'



function PersonalInfo({informations}) {
    const [enteredDisplayName, setEnteredDisplayName] = useState('')
    const displayNameChangeHandler = (event) =>{
        setEnteredDisplayName(event.target.value)
        
    }

    const [isEdit, setIsEdit] = useState(false)
    // const [isCancel, setCancel] = useState(true)

    const edit = () => {
        setIsEdit(true)
    }

    const cancel = () => {
        setIsEdit(false)
    }
  
    const submitHandler = (event) => {
        event.preventDefault();

        const personalInfoData ={
            displayName: enteredDisplayName
        }
        console.log(personalInfoData)
    }
    return (
            
        <form onSubmit={submitHandler}>
            {
                informations.map(info => <div className="personal-info">
                <div className="personal-info-body">
                <div onClick={edit} className="edit-btn" value="Edit" >
                    Edit <FaPencilAlt/>
                    </div>
                    <div className="personalInfo">Personal Info</div>
                    <div className="title">First Name</div>
                    <div className="dataInfo">{info.firstName}</div>
                    <div className="title">Middle Name</div>
                    <div className="dataInfo">{info.middleName}</div>
                    <div className="title">Last Name</div>
                    <div className="dataInfo">{info.lastName}</div>
                    <div className="title">Display Name</div>
                    <div className="dataInfo">{info.displayName}</div>
                    <div className="title">Date of Birth</div>
                    <div className="dataInfo">{info.dateOfBirth}</div>

                    </div><div className="edit-personal-info" style={{display: isEdit ? 'block' : 'none' }}>
                        <div className="editTitle">Display Name</div>
                        <input type="text" placeholder={info.displayName} onChange={displayNameChangeHandler}/>
                    <div>
                        <div className="save-btn">
                            <div type='submit' class="save-btn-text">Save</div>
                        </div>
                        <div className="cancel-btn" >
                            <div onClick={cancel} class="cancel-btn-text">Cancel</div>
                        </div>
                    </div>
                    </div>      
            </div>)
            }
        </form>

    )
       
    
}

export default PersonalInfo