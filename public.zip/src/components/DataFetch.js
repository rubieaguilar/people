import React from 'react'

function DataFetch() {
  return (
    <div>
      
    </div>
  )
}

export default DataFetch
