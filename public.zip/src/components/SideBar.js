import React from 'react'
import 'font-awesome/css/font-awesome.min.css';
import '../styles/SideBar.css'
import stitch from '../img/stitch.jpg'
import {infoData} from '../components/InfoData'





function SideBar() {
        return (
            <React.Fragment>
               
                <div className="wrapper">
                    <div className="profile-pic-wrapper">
                        <div className="profile-pic">
                            <img src={stitch} alt=""></img>
                        </div>
                    </div>
                                        
                    <div className="sidebar-content-wrapper">
                        <a href="/"className="displayName" alt="">{infoData[0].displayName}</a>
                        <a href="/" className="role" alt="">{infoData[0].role}</a>
                        <p className="location">{infoData[0].location}</p>
                        <p className="time">GMT +8 Manila</p>
                        <a href="/" className="email" alt="">{infoData[0].emailAddress}</a>
                    </div>
                </div>
                
                    
            </React.Fragment>
     
        )
    
    }
  

export default SideBar