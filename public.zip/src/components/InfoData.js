export const infoData = [
    {
        mobile : "09090909090",
        emailAddress: "asasa@gmail.com",
        emergencyName : "Gabo",
        emergencyAddress : "Gulod Itaas, Batangas City",
        emergencyDistrict : "5th",
        emergencyCity : "Batangas",
        emergencyCountry : "Philippines",
        emergencyPhone : "01234567890",
        firstName : "Rubie",
        middleName : "U",
        lastName : "Aguilar",
        displayName : "Rubie Aguilar",
        birthday : "11/09/1995",
        role : "Application Development Associate",
        location : "Taguig Uptown Bonifacio Tower 3",  
    
        
        
        
        

       
        
    }
]