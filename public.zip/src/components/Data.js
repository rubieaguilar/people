import React from 'react'
import PersonalInfo from './PersonalInfo'
import ContactInfo from './ContactInfo'


function Data({informations}) {
    return (
        <React.Fragment>
            <div className="data-container">
                <ContactInfo informations = {informations}/>
                <PersonalInfo informations = {informations}/>
            </div>
            
        </React.Fragment>
    )
}

export default Data
